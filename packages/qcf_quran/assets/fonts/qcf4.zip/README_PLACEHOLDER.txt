Placeholder for the real qcf4.zip (604 per-page QCF fonts).
Replace this file with the real qcf4.zip to enable PageviewQuran.
